﻿using MongoDB.Bson.Serialization.Attributes;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements] 
    public class Category : BaseEntity
    {
        public string? CategoryName { get; set; }  
        public string? Description { get; set; } 
        public string? Icon { get; set; }          
        public bool IsActive { get; set; } = true; 
    }
}
