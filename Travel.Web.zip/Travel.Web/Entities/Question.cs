﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Question : BaseEntity
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string? UserId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string? TourId { get; set; }

        public string? QuestionContent { get; set; }

        public string? AnswerContent { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Sorunun cevaplanma durumu 
        public bool IsStatus { get; set; } = false;
    }
}
