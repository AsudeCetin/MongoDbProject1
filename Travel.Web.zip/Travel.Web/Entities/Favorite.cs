﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Favorite : BaseEntity
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string? UserId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string? TourId { get; set; }

        // Telefon/Misafir müşterinin adı
        public string? GuestName { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
