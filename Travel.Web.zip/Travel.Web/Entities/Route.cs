﻿using MongoDB.Bson.Serialization.Attributes;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Route : BaseEntity
    {
        public string TourName { get; set; }      
        public string Description { get; set; }   

        public string City { get; set; }
        public string Country { get; set; }
        public string Duration { get; set; }
        public string ImageUrl { get; set; }
        public string Price { get; set; }
    }
}
