﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Comment : BaseEntity
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string? UserId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string? TourId { get; set; }

        public string? Content { get; set; }

        // Yorum puanı (1-5 arası yıldızlama için)
        public int Rating { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;      
        public bool IsActive { get; set; } = false;
    }
}
