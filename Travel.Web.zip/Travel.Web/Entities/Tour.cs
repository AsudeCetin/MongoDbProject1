﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Tour : BaseEntity
    {
        public string? Title { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Capacity { get; set; }
        public bool IsActive { get; set; } = true;
        public string? ImageUrl { get; set; }


        // --- İLİŞKİSEL REFERANSLAR (ID BAĞLANTILARI) ---
        [BsonRepresentation(BsonType.ObjectId)]
        public string? DestinationId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string? CategoryId { get; set; }

        //NESTED DOCUMENTS (GÖMÜLÜ DOKÜMANLAR)

        public List<TourDate> TourDates { get; set; } = new();
        public List<DailyProgram> DailyPrograms { get; set; } = new();
        public List<string> Gallery { get; set; } = new();
        public List<string> Features { get; set; } = new();
    }

 
    public class TourDate
    {
        public string DateId { get; set; } = Guid.NewGuid().ToString();
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int RemainingSlots { get; set; } 
    }

    public class DailyProgram
    {
        public int DayNumber { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
    }
}
