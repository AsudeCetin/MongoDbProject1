﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Reservation : BaseEntity
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string? UserId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string? TourId { get; set; }

     
        public string? TourDateId { get; set; }

        public int AdultCount { get; set; }

        public int ChildCount { get; set; }

        public int TotalParticipantCount => AdultCount + ChildCount;

        public DateTime ReservationDate { get; set; }

        public decimal TotalPrice { get; set; }


        public string? Status { get; set; } = "Bekliyor";

        [BsonElement("guestName")]
        public string? GuestName { get; set; }


        [BsonElement("phoneNumber")]
        public string? PhoneNumber { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
