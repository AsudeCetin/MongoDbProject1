﻿using MongoDB.Bson.Serialization.Attributes;
using Travel.Web.Entities.Common;

namespace Travel.Web.Entities
{
    [BsonIgnoreExtraElements]
    public class Banner : BaseEntity
    {
        public string? Title { get; set; }       
        public string? SubTitle { get; set; }  
        public string? ImageUrl { get; set; } 
        public bool IsActive { get; set; } = true;
    }
}
