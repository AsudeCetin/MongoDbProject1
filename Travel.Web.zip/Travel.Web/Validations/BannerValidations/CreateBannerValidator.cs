﻿using FluentValidation;
using Travel.Web.DTOs.BannerDtos;

namespace Travel.Web.ValidationRules.BannerValidators
{
    public class CreateBannerValidator : AbstractValidator<CreateBannerDto>
    {
        public CreateBannerValidator()
        {
            RuleFor(x => x.Title).NotEmpty().WithMessage("Banner ana başlığı boş geçilemez.");
            RuleFor(x => x.SubTitle).NotEmpty().WithMessage("Banner alt başlığı/slogan alanı boş geçilemez.");
            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Banner görsel URL adresi boş geçilemez.");
        }
    }
}
