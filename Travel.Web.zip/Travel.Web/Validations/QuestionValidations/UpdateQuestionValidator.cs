﻿using FluentValidation;
using Travel.Web.DTOs.QuestionDtos;

namespace Travel.Web.Validations.QuestionValidations
{
    public class UpdateQuestionValidator : AbstractValidator<UpdateQuestionDto>
    {
        public UpdateQuestionValidator()
        {
            // Sizin paylaştığınız DTO'daki string? Id alanıyla %100 uyumlu doğrulama
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Güncellenecek soru kimliği (ID) boş olamaz.");

            // Sizin paylaştığınız DTO'daki QuestionContent alanıyla %100 uyumlu doğrulama
            RuleFor(x => x.QuestionContent)
                .NotEmpty().WithMessage("Soru metni boş bırakılamaz.")
                .MinimumLength(10).WithMessage("Sorunuzun net anlaşılması için en az 10 karakter girilmelidir.");
        }
    }
}
