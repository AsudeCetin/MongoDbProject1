﻿using FluentValidation;
using Travel.Web.DTOs.QuestionDtos;

namespace Travel.Web.Validations.QuestionValidations
{
   
    public class CreateQuestionValidator : AbstractValidator<CreateQuestionDto>
    {
        public CreateQuestionValidator()
        {
            RuleFor(x => x.QuestionContent)
                .NotEmpty().WithMessage("Soru metni boş bırakılamaz.")
                .MinimumLength(10).WithMessage("Sorunuzun net anlaşılması için en az 10 karakter girilmelidir.");
        }
    }
}
