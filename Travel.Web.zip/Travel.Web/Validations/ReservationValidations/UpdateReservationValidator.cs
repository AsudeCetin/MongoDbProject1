﻿using FluentValidation;
using Travel.Web.DTOs.ReservationDtos;

namespace Travel.Web.Validations.ReservationValidations
{
    public class UpdateReservationValidator : AbstractValidator<UpdateReservationDto>
    {
        public UpdateReservationValidator()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Güncellenecek rezervasyon kimliği (ID) boş olamaz.");

            RuleFor(x => x.AdultCount)
                .GreaterThanOrEqualTo(1).WithMessage("Rezervasyon için en az 1 yetişkin bulunmalıdır.");
        }
    }
}
