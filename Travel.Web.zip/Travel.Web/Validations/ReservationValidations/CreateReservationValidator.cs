﻿using FluentValidation;
using Travel.Web.DTOs.ReservationDtos;

namespace Travel.Web.Validations.ReservationValidations
{
    public class CreateReservationValidator : AbstractValidator<CreateReservationDto>
    {
        public CreateReservationValidator()
        {
            RuleFor(x => x.AdultCount)
                .GreaterThanOrEqualTo(1).WithMessage("Rezervasyon yapabilmek için en az 1 yetişkin seçilmelidir.");

            RuleFor(x => x.TourId)
                .NotEmpty().WithMessage("Rezervasyon yapılacak tur alanı boş bırakılamaz.");
        }
    }
}
