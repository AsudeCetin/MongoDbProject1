﻿using FluentValidation;
using System.Data;
using Travel.Web.DTOs.RouteDtos;

namespace Travel.Web.Validations.RouteValidations
{
    public class CreateRouteValidator:AbstractValidator<CreateRouteDto>
    {
        public CreateRouteValidator()
        {
            RuleFor(x => x.City).NotEmpty().WithMessage("Şehir boş olamaz.");
            RuleFor(x => x.Country).NotEmpty().WithMessage("Ülke boş olamaz.");
            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Görsel Url boş olamaz.");
            RuleFor(x => x.Duration).NotEmpty().WithMessage("Tur Süresi boş olamaz.");
            RuleFor(x => x.Price).NotEmpty().WithMessage("Fiyat boş olamaz.");
        }
    }
}
