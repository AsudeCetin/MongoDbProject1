﻿using FluentValidation;
using Travel.Web.DTOs.FavoriteDtos;

namespace Travel.Web.Validations.FavoriteValidations
{
    public class UpdateFavoriteValidator : AbstractValidator<UpdateFavoriteDto>
    {
        public UpdateFavoriteValidator()
        {
           
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Güncellenecek favori kayıt ID'si boş olamaz.");

            RuleFor(x => x.UserId)
                .NotEmpty().WithMessage("Kullanıcı kimliği boş olamaz.");

            RuleFor(x => x.TourId)
                .NotEmpty().WithMessage("Tur kimliği boş olamaz.");
        }
    }
}
