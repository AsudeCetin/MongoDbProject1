﻿using FluentValidation;
using Travel.Web.DTOs.FavoriteDtos;

namespace Travel.Web.Validations.FavoriteValidations
{
    public class CreateFavoriteValidator : AbstractValidator<CreateFavoriteDto>
    {
        public CreateFavoriteValidator()
        {
       
            RuleFor(x => x.UserId)
                .NotEmpty().WithMessage("Kullanıcı kimliği boş olamaz.");

            RuleFor(x => x.TourId)
                .NotEmpty().WithMessage("Favoriye eklenecek tur kimliği boş olamaz.");
        }
    }
}
