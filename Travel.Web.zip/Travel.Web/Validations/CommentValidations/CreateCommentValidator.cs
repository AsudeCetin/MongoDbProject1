﻿using FluentValidation;
using Travel.Web.DTOs.CommentDtos;

namespace Travel.Web.Validations.CommentValidations
{
    public class CreateCommentValidator : AbstractValidator<CreateCommentDto>
    {
        public CreateCommentValidator()
        {
            RuleFor(x => x.Content)
                .NotEmpty().WithMessage("Yorum içeriği boş bırakılamaz.")
                .MaximumLength(500).WithMessage("Yorum metni en fazla 500 karakter olabilir.");

   
            RuleFor(x => x.Rating)
                .InclusiveBetween(1, 5).WithMessage("Puanlama 1 ile 5 yıldız arasında olmalıdır.");
        }
    }
}
