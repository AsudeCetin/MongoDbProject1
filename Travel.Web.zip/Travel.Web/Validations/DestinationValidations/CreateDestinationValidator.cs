﻿using FluentValidation;
using Travel.Web.DTOs.DestinationDtos;

namespace Travel.Web.Validations.DestinationValidations
{
    public class CreateDestinationValidator : AbstractValidator<CreateDestinationDto>
    {
        public CreateDestinationValidator()
        {
           
            RuleFor(x => x.City)
                .NotEmpty().WithMessage("Destinasyon şehir adı boş bırakılamaz.");

            RuleFor(x => x.Country)
                .NotEmpty().WithMessage("Destinasyon ülke adı boş bırakılamaz.");

            RuleFor(x => x.ImageUrl)
                .NotEmpty().WithMessage("Destinasyon görsel linki boş bırakılamaz.");
        }
    }
}

