﻿using FluentValidation;
using Travel.Web.DTOs.DestinationDtos;

namespace Travel.Web.Validations.DestinationValidations
{
    public class UpdateDestinationValidator : AbstractValidator<UpdateDestinationDto>
    {
        public UpdateDestinationValidator()
        {
            
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Güncellenecek destinasyon ID'si boş olamaz.");

            RuleFor(x => x.City)
                .NotEmpty().WithMessage("Destinasyon şehir adı boş bırakılamaz.");

            RuleFor(x => x.Country)
                .NotEmpty().WithMessage("Destinasyon ülke adı boş bırakılamaz.");
        }
    }
}
