﻿using FluentValidation;
using Travel.Web.DTOs.TourDtos;

namespace Travel.Web.Validations.TourValidations
{
    public class UpdateTourValidator : AbstractValidator<UpdateTourDto>
    {
        public UpdateTourValidator()
        {
            RuleFor(x => x.Id)
                .NotEmpty().WithMessage("Güncellenecek tur kimliği (ID) boş olamaz.");

            RuleFor(x => x.Title)
                .NotEmpty().WithMessage("Tur başlığı boş geçilemez.")
                .MinimumLength(5).WithMessage("Tur başlığı en az 5 karakter olmalıdır.");

            RuleFor(x => x.Price)
                .GreaterThan(0).WithMessage("Tur fiyatı 0'dan büyük olmalıdır.");

            RuleFor(x => x.Capacity)
                .GreaterThan(0).WithMessage("Tur kapasitesi en az 1 kişi olmalıdır.");
        }
    }
}
