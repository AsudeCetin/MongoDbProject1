﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.ReservationDtos;
using Travel.Web.Services.ReservationServices;
using Travel.Web.Services.UserServices;
using Travel.Web.Services.TourServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class ReservationController : Controller
    {
        private readonly IReservationService _reservationService;
        private readonly IUserService _userService;
        private readonly ITourService _tourService;

        public ReservationController(IReservationService reservationService, IUserService userService, ITourService tourService)
        {
            _reservationService = reservationService;
            _userService = userService;
            _tourService = tourService;
        }

        private async Task LoadDropdownDataAsync()
        {
            var users = await _userService.GetAllAsync();
            var tours = await _tourService.GetAllAsync();

            ViewBag.Users = users.Select(x => new SelectListItem
            {
                Text = x.NameSurname,
                Value = x.Id
            }).ToList();

            ViewBag.Tours = tours.Select(x => new SelectListItem
            {
                Text = x.Title,
                Value = x.Id
            }).ToList();
        }
        public async Task<IActionResult> Index(string search, string status)
        {
            var values = await _reservationService.GetAllReservationAsync();

            if (values != null && values.Any())
            {
         
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (!string.IsNullOrEmpty(x.UserFullName) && x.UserFullName.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.TourTitle) && x.TourTitle.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.Status) && x.Status.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }
                if (!string.IsNullOrEmpty(status))
                {
                    values = values.Where(x => !string.IsNullOrEmpty(x.Status) && x.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
                }
            }

            return View(values);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadDropdownDataAsync();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateReservationDto createReservationDto, string? GuestNameSurname)
        {
            if (createReservationDto.UserId == "TELEPHONE_GUEST")
            {
                createReservationDto.UserId = "000000000000000000000000";
            }

            if (createReservationDto.TourId == "SAMPLE_TOUR_ID")
            {
                createReservationDto.TourId = "111111111111111111111111";
            }

            await _reservationService.CreateReservationAsync(createReservationDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _reservationService.DeleteReservationAsync(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            var value = await _reservationService.GetByIdReservationAsync(id);

            if (value == null)
            {
                return NotFound("Güncellenecek rezervasyon kaydı bulunamadı.");
            }

            var updateDto = new Travel.Web.DTOs.ReservationDtos.UpdateReservationDto
            {
                Id = value.Id,
                UserId = value.UserId,
                TourId = value.TourId,
                AdultCount = value.AdultCount,
                ChildCount = value.ChildCount,
                ReservationDate = value.ReservationDate,
                TotalPrice = value.TotalPrice,
                Status = value.Status,
                PhoneNumber = value.PhoneNumber,
                GuestName = value.GuestName 
            };

            return View(updateDto);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateReservationDto updateReservationDto)
        {
            
            if (updateReservationDto.UserId == "TELEPHONE_GUEST")
            {
                updateReservationDto.UserId = "000000000000000000000000";
            }

            if (updateReservationDto.TourId == "SAMPLE_TOUR_ID")
            {
                updateReservationDto.TourId = "111111111111111111111111";
            }

            await _reservationService.UpdateReservationAsync(updateReservationDto);
            return RedirectToAction("Index");
        }

    }
}
