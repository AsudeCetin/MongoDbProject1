﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.Services.CategoryServices;
using Travel.Web.Services.DestinationServices;
using Travel.Web.Services.TourServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class TourController : Controller
    {
        private readonly ITourService _tourService;
        private readonly ICategoryService _categoryService;
        private readonly IDestinationService _destinationService;

        public TourController(ITourService tourService, ICategoryService categoryService, IDestinationService destinationService)
        {
            _tourService = tourService;
            _categoryService = categoryService;
            _destinationService = destinationService;
        }

        [HttpGet]
        public async Task<IActionResult> Index(string search, string destinationId, string categoryId, string status)
        {
            var values = await _tourService.GetAllAsync();

            ViewBag.TotalTourCount = values != null ? values.Count : 0;
            ViewBag.ActiveTourCount = values != null ? values.Count(x => !x.IsActive) : 0;
            ViewBag.TotalReservationCount = 8;
            ViewBag.TotalCapacity = values != null ? values.Sum(x => x.Capacity) : 0;

            var categories = await _categoryService.GetAllAsync();
            var destinations = await _destinationService.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "CategoryName");
            ViewBag.Destinations = new SelectList(destinations, "Id", "City");

            if (values != null && values.Any())
            {
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (x.Title != null && x.Title.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (x.Description != null && x.Description.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }

                if (!string.IsNullOrEmpty(destinationId))
                {
                    values = values.Where(x => x.DestinationId == destinationId).ToList();
                }

                if (!string.IsNullOrEmpty(categoryId))
                {
                    values = values.Where(x => x.CategoryId == categoryId).ToList();
                }

                if (!string.IsNullOrEmpty(status))
                {
                    bool statusBool = status == "true";
                    values = values.Where(x => x.IsActive == statusBool).ToList();
                }
            }

            ViewBag.SearchValue = search;
            return View(values);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var categories = await _categoryService.GetAllAsync();
            var destinations = await _destinationService.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "CategoryName");
            ViewBag.Destinations = new SelectList(destinations, "Id", "City");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(dynamic createTourDto)
        {
            await _tourService.CreateAsync(createTourDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _tourService.DeleteAsync(id);
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            if (string.IsNullOrEmpty(id) && HttpContext.Request.Query.ContainsKey("id"))
            {
                id = HttpContext.Request.Query["id"];
            }

            if (string.IsNullOrEmpty(id))
            {
                return RedirectToAction("Index");
            }

            var value = await _tourService.GetByIdAsync(id);
            if (value == null)
            {
                return RedirectToAction("Index");
            }

            var categories = await _categoryService.GetAllAsync();
            var destinations = await _destinationService.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "CategoryName", value.CategoryId);
            ViewBag.Destinations = new SelectList(destinations, "Id", "City", value.DestinationId);

            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(dynamic updateTourDto)
        {
            await _tourService.UpdateAsync(updateTourDto);
            return RedirectToAction("Index");
        }
    }
}

