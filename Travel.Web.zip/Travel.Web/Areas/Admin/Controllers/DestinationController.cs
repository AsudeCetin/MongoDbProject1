﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.DestinationDtos;
using Travel.Web.Services.DestinationServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class DestinationController : Controller
    {
        private readonly IDestinationService _destinationService;

        public DestinationController(IDestinationService destinationService)
        {
            _destinationService = destinationService;
        }

     
        public async Task<IActionResult> Index(string search, string status)
        {
        
            var values = await _destinationService.GetAllAsync();

            if (values != null && values.Any())
            {
                
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (!string.IsNullOrEmpty(x.City) && x.City.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.Country) && x.Country.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.Description) && x.Description.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }

                if (!string.IsNullOrEmpty(status))
                {
                    bool isStatusActive = bool.Parse(status);
                    values = values.Where(x => x.IsActive == isStatusActive).ToList();
                }
            }

            return View(values);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateDestinationDto createDestinationDto)
        {
            await _destinationService.CreateAsync(createDestinationDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _destinationService.DeleteAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            var value = await _destinationService.GetByIdAsync(id);
            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateDestinationDto updateDestinationDto)
        {
            await _destinationService.UpdateAsync(updateDestinationDto);
            return RedirectToAction("Index");
        }
    }
}
