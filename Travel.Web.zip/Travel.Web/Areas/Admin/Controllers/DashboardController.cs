﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Travel.Web.Services.DashboardServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class DashboardController : Controller
    {
        private readonly IDashboardService _dashboardService;

        public DashboardController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        public async Task<IActionResult> Index()
        {
            // Orijinal kodunuz birebir korundu
            var values = await _dashboardService.GetDashboardStatisticsAsync();
            return View(values);
        }
    }
}
