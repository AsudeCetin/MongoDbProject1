﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.CommentDtos; 
using Travel.Web.Services.CommentServices;
using Travel.Web.Services.UserServices;
using Travel.Web.Services.TourServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class CommentController : Controller
    {
        private readonly ICommentService _commentService;
        private readonly IUserService _userService;
        private readonly ITourService _tourService;

        public CommentController(ICommentService commentService, IUserService userService, ITourService tourService)
        {
            _commentService = commentService;
            _userService = userService;
            _tourService = tourService;
        }

        private async Task LoadDropdownsDataAsync()
        {
            var users = await _userService.GetAllAsync();
            var tours = await _tourService.GetAllAsync();

            ViewBag.Users = users.Select(x => new SelectListItem
            {
                Text = x.NameSurname,
                Value = x.Id
            }).ToList();

            ViewBag.Tours = tours.Select(x => new SelectListItem
            {
                Text = x.Title,
                Value = x.Id
            }).ToList();
        }

        public async Task<IActionResult> Index(string search, string status)
        {
            var values = await _commentService.GetAllCommentAsync();

            if (values != null && values.Any())
            {
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (!string.IsNullOrEmpty(x.UserFullName) && x.UserFullName.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.TourTitle) && x.TourTitle.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.Content) && x.Content.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }

                if (!string.IsNullOrEmpty(status))
                {
                    if (bool.TryParse(status, out bool isStatusActive))
                    {
                        values = values.Where(x => x.IsActive == isStatusActive).ToList();
                    }
                }
            }

            return View(values);
        }
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadDropdownsDataAsync();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateCommentDto createCommentDto, string GuestNameSurname)
        {
            if (createCommentDto.UserId == "TELEPHONE_GUEST")
            {
                createCommentDto.UserId = "000000000000000000000000";
                if (!string.IsNullOrEmpty(GuestNameSurname))
                {
                    createCommentDto.Content = $"[Telefon Müşterisi: {GuestNameSurname}] - " + createCommentDto.Content;
                }
            }

            if (createCommentDto.TourId == "SAMPLE_TOUR_ID")
            {
                createCommentDto.TourId = "111111111111111111111111";
            }

            await _commentService.CreateCommentAsync(createCommentDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _commentService.DeleteCommentAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            await LoadDropdownsDataAsync();
            var value = await _commentService.GetByIdCommentAsync(id);
            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateCommentDto updateCommentDto, string GuestNameSurname)
        {
            if (updateCommentDto.UserId == "TELEPHONE_GUEST")
            {
                updateCommentDto.UserId = "000000000000000000000000";

                if (!string.IsNullOrEmpty(GuestNameSurname) && !updateCommentDto.Content.Contains(GuestNameSurname))
                {
                    updateCommentDto.Content = $"[Telefon Müşterisi: {GuestNameSurname}] - " + updateCommentDto.Content;
                }
            }

            if (updateCommentDto.TourId == "SAMPLE_TOUR_ID")
            {
                updateCommentDto.TourId = "111111111111111111111111";
            }

            await _commentService.UpdateCommentAsync(updateCommentDto);
            return RedirectToAction("Index");
        }
    }
}
