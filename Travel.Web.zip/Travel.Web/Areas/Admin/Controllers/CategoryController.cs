﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.CategoryDtos;
using Travel.Web.Services.CategoryServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class CategoryController : Controller
    {
        private readonly ICategoryService _categoryService;

        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        // CANLI FİLTRELEME VE ARAMA DESTEKLİ INDEX AKSİYONU
        public async Task<IActionResult> Index(string search, string status)
        {
            // 1. MongoDB'den tüm kategorileri çekiyoruz
            var values = await _categoryService.GetAllAsync();

            // 2. Arama ve Durum Filtreleri Tetikleniyor
            if (values != null && values.Any())
            {
                // Kelime ile arama yapıldıysa süz
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x => !string.IsNullOrEmpty(x.CategoryName) &&
                                               x.CategoryName.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
                }

                // Aktif/Pasif durum seçildiyse süz
                if (!string.IsNullOrEmpty(status))
                {
                    bool isStatusActive = bool.Parse(status);
                    values = values.Where(x => x.IsActive == isStatusActive).ToList();
                }
            }

            return View(values);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateCategoryDto createCategoryDto)
        {
            if (!ModelState.IsValid)
            {
                return View(createCategoryDto);
            }
            await _categoryService.CreateAsync(createCategoryDto);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            if (string.IsNullOrEmpty(id) && HttpContext.Request.Query.ContainsKey("id"))
            {
                id = HttpContext.Request.Query["id"];
            }

            var value = await _categoryService.GetByIdAsync(id);
            if (value == null)
            {
                return RedirectToAction("Index");
            }
            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateCategoryDto updateCategoryDto)
        {
            if (!ModelState.IsValid)
            {
                return View(updateCategoryDto);
            }
            await _categoryService.UpdateAsync(updateCategoryDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id) && HttpContext.Request.Query.ContainsKey("id"))
            {
                id = HttpContext.Request.Query["id"];
            }

            if (!string.IsNullOrEmpty(id))
            {
                await _categoryService.DeleteAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
