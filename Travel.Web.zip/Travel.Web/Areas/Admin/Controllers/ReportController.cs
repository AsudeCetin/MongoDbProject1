﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.Services.ReportServices;
using Travel.Web.Services.ReservationServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/Report")]
    public class ReportController : Controller
    {
        private readonly IReportService _reportService;
        private readonly IReservationService _reservationService;

        public ReportController(IReportService reportService, IReservationService reservationService)
        {
            _reportService = reportService;
            _reservationService = reservationService;
        }

        [HttpGet("DownloadExcel")]
        public async Task<IActionResult> DownloadExcel(string tourId = null)
        {
            var reservations = await _reservationService.GetAllReservationAsync();

            // Eğer tourId dolu geldiyse listeyi sadece o tura ait olanlar için filtrele
            if (!string.IsNullOrEmpty(tourId))
            {
                reservations = reservations.Where(x => x.TourId == tourId).ToList();
            }

            var fileContents = _reportService.GenerateExcelReport(reservations, tourId);
            string fileName = string.IsNullOrEmpty(tourId) ? "Genel_Katilimci_Raporu" : $"Tur_{tourId}_Katilimci_Raporu";

            return File(
                fileContents,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"{fileName}_{DateTime.Now:yyyyMMdd}.xlsx"
            );
        }

        [HttpGet("DownloadPdf")]
        public async Task<IActionResult> DownloadPdf(string tourId = null)
        {
            var reservations = await _reservationService.GetAllReservationAsync();

            // Eğer tourId dolu geldiyse listeyi sadece o tura ait olanlar için filtrele
            if (!string.IsNullOrEmpty(tourId))
            {
                reservations = reservations.Where(x => x.TourId == tourId).ToList();
            }

            var fileContents = _reportService.GeneratePdfReport(reservations, tourId);
            string fileName = string.IsNullOrEmpty(tourId) ? "Genel_Katilimci_Raporu" : $"Tur_{tourId}_Katilimci_Raporu";

            return File(
                fileContents,
                "application/pdf",
                $"{fileName}_{DateTime.Now:yyyyMMdd}.pdf"
            );
        }
    }
}
