﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.QuestionDtos;
using Travel.Web.Services.QuestionServices;
using Travel.Web.Services.UserServices;
using Travel.Web.Services.TourServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class QuestionController : Controller
    {
        private readonly IQuestionService _questionService;
        private readonly IUserService _userService;
        private readonly ITourService _tourService;

        public QuestionController(IQuestionService questionService, IUserService userService, ITourService tourService)
        {
            _questionService = questionService;
            _userService = userService;
            _tourService = tourService;
        }

        private async Task LoadDropdownDataAsync()
        {
            var users = await _userService.GetAllAsync();
            var tours = await _tourService.GetAllAsync();

            ViewBag.Users = users.Select(x => new SelectListItem
            {
                Text = x.NameSurname,
                Value = x.Id
            }).ToList();

            ViewBag.Tours = tours.Select(x => new SelectListItem
            {
                Text = x.Title,
                Value = x.Id
            }).ToList();
        }

        // FİLTRELEME DESTEKLİ INDEX METODU
        public async Task<IActionResult> Index(string search, string status)
        {
            var values = await _questionService.GetAllQuestionAsync();

            if (values != null && values.Any())
            {
                // Kullanıcı adı, Tur adı, Soru veya Cevap içeriğinde ara
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (!string.IsNullOrEmpty(x.UserFullName) && x.UserFullName.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.TourTitle) && x.TourTitle.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.QuestionContent) && x.QuestionContent.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.AnswerContent) && x.AnswerContent.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }

                // Durum süzgeci
                if (!string.IsNullOrEmpty(status))
                {
                    bool isStatusActive = bool.Parse(status);
                    values = values.Where(x => x.IsStatus == isStatusActive).ToList();
                }
            }

            return View(values);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadDropdownDataAsync();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateQuestionDto createQuestionDto, string? GuestNameSurname)
        {
            if (createQuestionDto.UserId == "TELEPHONE_GUEST")
            {
                createQuestionDto.UserId = "000000000000000000000000";
                if (!string.IsNullOrEmpty(GuestNameSurname))
                {
                    createQuestionDto.QuestionContent = $"[Telefon Müşterisi: {GuestNameSurname}] - {createQuestionDto.QuestionContent}";
                }
            }

            if (createQuestionDto.TourId == "SAMPLE_TOUR_ID")
            {
                createQuestionDto.TourId = "111111111111111111111111";
            }

            await _questionService.CreateQuestionAsync(createQuestionDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _questionService.DeleteQuestionAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            await LoadDropdownDataAsync();
            var value = await _questionService.GetByIdQuestionAsync(id);
            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateQuestionDto updateQuestionDto, string? GuestNameSurname)
        {
            if (updateQuestionDto.UserId == "TELEPHONE_GUEST")
            {
                updateQuestionDto.UserId = "000000000000000000000000";

                if (!string.IsNullOrEmpty(GuestNameSurname) && !updateQuestionDto.QuestionContent.Contains(GuestNameSurname))
                {
                    updateQuestionDto.QuestionContent = $"[Telefon Müşterisi: {GuestNameSurname}] - {updateQuestionDto.QuestionContent}";
                }
            }

            if (updateQuestionDto.TourId == "SAMPLE_TOUR_ID")
            {
                updateQuestionDto.TourId = "111111111111111111111111";
            }

            await _questionService.UpdateQuestionAsync(updateQuestionDto);
            return RedirectToAction("Index");
        }
    }
}
