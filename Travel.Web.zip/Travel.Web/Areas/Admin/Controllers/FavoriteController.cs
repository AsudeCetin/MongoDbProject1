﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.FavoriteDtos;
using Travel.Web.Services.FavoriteServices;
using Travel.Web.Services.UserServices;
using Travel.Web.Services.TourServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class FavoriteController : Controller
    {
        private readonly IFavoriteService _favoriteCollection;
        private readonly IUserService _userService;
        private readonly ITourService _tourService;

        public FavoriteController(IFavoriteService favoriteCollection, IUserService userService, ITourService tourService)
        {
            _favoriteCollection = favoriteCollection;
            _userService = userService;
            _tourService = tourService;
        }

        private async Task LoadDropdownDataAsync()
        {
            var users = await _userService.GetAllAsync();
            var tours = await _tourService.GetAllAsync();

            ViewBag.Users = users.Select(x => new SelectListItem
            {
                Text = x.NameSurname,
                Value = x.Id
            }).ToList();

            ViewBag.Tours = tours.Select(x => new SelectListItem
            {
                Text = x.Title,
                Value = x.Id
            }).ToList();
        }

      
        public async Task<IActionResult> Index(string search)
        {
            var values = await _favoriteCollection.GetAllFavoriteAsync();

            if (values != null && values.Any())
            {
                if (!string.IsNullOrEmpty(search))
                {
                    values = values.Where(x =>
                        (!string.IsNullOrEmpty(x.UserFullName) && x.UserFullName.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.GuestName) && x.GuestName.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(x.TourTitle) && x.TourTitle.Contains(search, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }
            }

            return View(values);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadDropdownDataAsync();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateFavoriteDto createFavoriteDto, string? GuestNameSurname)
        {
            if (createFavoriteDto.UserId == "TELEPHONE_GUEST")
            {
                createFavoriteDto.UserId = "000000000000000000000000";
                createFavoriteDto.GuestName = GuestNameSurname;
            }

            if (createFavoriteDto.TourId == "SAMPLE_TOUR_ID")
            {
                createFavoriteDto.TourId = "111111111111111111111111";
            }

            await _favoriteCollection.CreateFavoriteAsync(createFavoriteDto);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _favoriteCollection.DeleteFavoriteAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Update(string id)
        {
            await LoadDropdownDataAsync();
            var value = await _favoriteCollection.GetByIdFavoriteAsync(id);
            return View(value);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateFavoriteDto updateFavoriteDto, string? GuestNameSurname)
        {
            if (updateFavoriteDto.UserId == "TELEPHONE_GUEST")
            {
                updateFavoriteDto.UserId = "000000000000000000000000";
                updateFavoriteDto.GuestName = GuestNameSurname;
            }

            if (updateFavoriteDto.TourId == "SAMPLE_TOUR_ID")
            {
                updateFavoriteDto.TourId = "111111111111111111111111";
            }

            await _favoriteCollection.UpdateFavoriteAsync(updateFavoriteDto);
            return RedirectToAction("Index");
        }
    }
}
