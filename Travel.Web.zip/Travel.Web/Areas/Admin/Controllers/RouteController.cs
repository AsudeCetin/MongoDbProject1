﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.RouteDtos;
using Travel.Web.Services.RouteServices;

namespace Travel.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class RouteController(IRouteService _routeService, IMapper _mapper) : Controller
    {
      
        public async Task<IActionResult> Index(string searchString)
        {
            var routes = await _routeService.GetAllAsync();

            if (!string.IsNullOrEmpty(searchString))
            {
                var lowerSearch = searchString.ToLower().Trim();
                routes = routes.Where(x =>
                    (x.TourName != null && x.TourName.ToLower().Contains(lowerSearch)) ||
                    (x.City != null && x.City.ToLower().Contains(lowerSearch)) ||
                    (x.Country != null && x.Country.ToLower().Contains(lowerSearch))
                ).ToList();
            }

            return View(routes);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateRouteDto routeDto)
        {
            if (!ModelState.IsValid)
            {
                return View(routeDto);
            }
            await _routeService.CreateAsync(routeDto);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(string id)
        {
            var route = await _routeService.GetByIdAsync(id);
            var updateRoute = _mapper.Map<UpdateRouteDto>(route);
            return View(updateRoute);
        }

        [HttpPost]
        public async Task<IActionResult> Update(UpdateRouteDto updateRouteDto)
        {
            if (!ModelState.IsValid)
            {
                return View(updateRouteDto);
            }
            await _routeService.UpdateAsync(updateRouteDto);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(string id)
        {
            await _routeService.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
