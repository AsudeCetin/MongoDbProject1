﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.FavoriteDtos;

namespace Travel.Web.Services.FavoriteServices
{
    public interface IFavoriteService
    {
        Task<List<ResultFavoriteDto>> GetAllFavoriteAsync();
        Task CreateFavoriteAsync(CreateFavoriteDto createFavoriteDto);
        Task UpdateFavoriteAsync(UpdateFavoriteDto updateFavoriteDto);
        Task DeleteFavoriteAsync(string id);
        Task<UpdateFavoriteDto> GetByIdFavoriteAsync(string id);
    }
}
