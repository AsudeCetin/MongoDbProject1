﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.FavoriteDtos;
using Travel.Web.Entities;
using Travel.Web.Settings;

namespace Travel.Web.Services.FavoriteServices
{
    public class FavoriteService : IFavoriteService
    {
        private readonly IMongoCollection<Favorite> _favoriteCollection;
        private readonly IMapper _mapper;

        public FavoriteService(IMapper mapper, IDatabaseSettings databaseSettings)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            var database = client.GetDatabase(databaseSettings.DatabaseName);

            _favoriteCollection = database.GetCollection<Favorite>(databaseSettings.FavoriteCollectionName);
            _mapper = mapper;
        }

        public async Task<List<ResultFavoriteDto>> GetAllFavoriteAsync()
        {
            var pipeline = new BsonDocument[]
            {
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Users" },
                    { "localField", "UserId" },
                    { "foreignField", "_id" },
                    { "as", "UserData" }
                }),
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$UserData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Tours" },
                    { "localField", "TourId" },
                    { "foreignField", "_id" },
                    { "as", "TourData" }
                }),
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$TourData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
                new BsonDocument("$project", new BsonDocument
                {
                    { "_id", 1 },
                    { "UserId", "$UserId" },
                    { "UserFullName", "$UserData.NameSurname" },
                    { "TourId", "$TourId" },
                    { "TourTitle", "$TourData.Title" },
                    { "GuestName", "$GuestName" }, 
                    { "CreatedAt", "$CreatedAt" }
                })
            };

            var aggregateFluent = await _favoriteCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
            var resultFavoriteDtos = new List<ResultFavoriteDto>();

            foreach (var doc in aggregateFluent)
            {
                
                string? displayName = doc.Contains("GuestName") && !doc["GuestName"].IsBsonNull ? doc["GuestName"].ToString() : null;
                if (string.IsNullOrEmpty(displayName))
                {
                    displayName = doc.Contains("UserFullName") && !doc["UserFullName"].IsBsonNull ? doc["UserFullName"].ToString() : null;
                }

                resultFavoriteDtos.Add(new ResultFavoriteDto
                {
                    Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                    UserId = doc.Contains("UserId") && !doc["UserId"].IsBsonNull ? doc["UserId"].ToString() : null,
                    UserFullName = displayName,
                    TourId = doc.Contains("TourId") && !doc["TourId"].IsBsonNull ? doc["TourId"].ToString() : null,
                    TourTitle = doc.Contains("TourTitle") && !doc["TourTitle"].IsBsonNull ? doc["TourTitle"].ToString() : null,
                    CreatedAt = doc.Contains("CreatedAt") && !doc["CreatedAt"].IsBsonNull ? doc["CreatedAt"].ToUniversalTime() : DateTime.MinValue
                });
            }

            return resultFavoriteDtos;
        }

        public async Task CreateFavoriteAsync(CreateFavoriteDto createFavoriteDto)
        {
            var favorite = _mapper.Map<Favorite>(createFavoriteDto);
            await _favoriteCollection.InsertOneAsync(favorite);
        }

        public async Task UpdateFavoriteAsync(UpdateFavoriteDto updateFavoriteDto)
        {
            var favorite = _mapper.Map<Favorite>(updateFavoriteDto);
            await _favoriteCollection.FindOneAndReplaceAsync(x => x.Id == updateFavoriteDto.Id, favorite);
        }

        public async Task DeleteFavoriteAsync(string id)
        {
            await _favoriteCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task<UpdateFavoriteDto> GetByIdFavoriteAsync(string id)
        {
            var value = await _favoriteCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<UpdateFavoriteDto>(value);
        }
    }
}
