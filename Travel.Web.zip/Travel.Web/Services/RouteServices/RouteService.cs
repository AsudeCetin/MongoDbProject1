﻿using AutoMapper;
using MongoDB.Driver;
using Travel.Web.DTOs.RouteDtos;
using route= Travel.Web.Entities.Route;
using Travel.Web.Settings;
using MongoDB.Driver.Linq;

namespace Travel.Web.Services.RouteServices
{   
    public class RouteService : IRouteService
    {
        private readonly IMongoCollection<route> _routeCollection;
        private readonly IMapper _mapper;

        public RouteService(IMapper mapper, IDatabaseSettings databaseSettings)
        {
            _mapper = mapper;
            var client = new MongoClient(databaseSettings.ConnectionString);
            var database = client.GetDatabase(databaseSettings.DatabaseName);
            _routeCollection = database.GetCollection<route>(databaseSettings.RouteCollectionName);
        }

        async Task IRouteService.CreateAsync(CreateRouteDto createRouteDto)
        {
            var route = _mapper.Map<route>(createRouteDto);
            await _routeCollection.InsertOneAsync(route);
        }

        async Task IRouteService.DeleteAsync(string id)
        {
            await _routeCollection.DeleteOneAsync(x => x.Id == id);
        }

        async Task<List<ResultRouteDto>> IRouteService.GetAllAsync()
        {
            var routes = await _routeCollection.AsQueryable().ToListAsync();
            return _mapper.Map<List<ResultRouteDto>>(routes);

        }

        async Task<List<ResultRouteDto>> IRouteService.GetAllCityAsync(string city)
        {
           var routes= await _routeCollection.Find(x => x.City == city).ToListAsync();
            return _mapper.Map<List<ResultRouteDto>>(routes);
        }

        async Task<ResultRouteDto> IRouteService.GetByIdAsync(string id)
        {
            var route=await _routeCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<ResultRouteDto>(route);
        }

        async Task IRouteService.UpdateAsync(UpdateRouteDto updateRouteDto)
        {
          var route = _mapper.Map<route>(updateRouteDto);
            await _routeCollection.FindOneAndReplaceAsync(x => x.Id == route.Id, route);
        }
    }
}
