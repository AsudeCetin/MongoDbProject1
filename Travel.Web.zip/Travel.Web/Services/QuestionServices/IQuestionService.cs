﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.QuestionDtos;

namespace Travel.Web.Services.QuestionServices
{
    public interface IQuestionService
    {
        Task<List<ResultQuestionDto>> GetAllQuestionAsync();
        Task CreateQuestionAsync(CreateQuestionDto createQuestionDto);
        Task UpdateQuestionAsync(UpdateQuestionDto updateQuestionDto);
        Task DeleteQuestionAsync(string id);
        Task<UpdateQuestionDto> GetByIdQuestionAsync(string id);
    }
}
