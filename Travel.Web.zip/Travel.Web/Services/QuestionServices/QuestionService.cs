﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.QuestionDtos;
using Travel.Web.Entities;
using Travel.Web.Settings;

namespace Travel.Web.Services.QuestionServices
{
    public class QuestionService : IQuestionService
    {
        private readonly IMongoCollection<Question> _questionCollection;
        private readonly IMapper _mapper;

        public QuestionService(IMapper mapper, IDatabaseSettings databaseSettings)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            var database = client.GetDatabase(databaseSettings.DatabaseName);

            _questionCollection = database.GetCollection<Question>(databaseSettings.QuestionCollectionName);
            _mapper = mapper;
        }

        public async Task<List<ResultQuestionDto>> GetAllQuestionAsync()
        {
            var pipeline = new BsonDocument[]
            {
                
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Users" },
                    { "localField", "UserId" },
                    { "foreignField", "_id" },
                    { "as", "UserData" }
                }),
              
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$UserData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
              
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Tours" },
                    { "localField", "TourId" },
                    { "foreignField", "_id" },
                    { "as", "TourData" }
                }),
             
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$TourData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
          
                new BsonDocument("$project", new BsonDocument
                {
                    { "_id", 1 },
                    { "UserId", "$UserId" },
                    { "UserFullName", "$UserData.NameSurname" },
                    { "TourId", "$TourId" },
                    { "TourTitle", "$TourData.Title" },
                    { "QuestionContent", "$QuestionContent" },
                    { "AnswerContent", "$AnswerContent" },
                    { "CreatedAt", "$CreatedAt" },
                    { "IsStatus", "$IsStatus" }
                })
            };

   
            var aggregateFluent = await _questionCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
            var resultQuestionDtos = new List<ResultQuestionDto>();

            foreach (var doc in aggregateFluent)
            {
                resultQuestionDtos.Add(new ResultQuestionDto
                {
                    Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                    UserId = doc.Contains("UserId") && !doc["UserId"].IsBsonNull ? doc["UserId"].ToString() : null,
                    UserFullName = doc.Contains("UserFullName") && !doc["UserFullName"].IsBsonNull ? doc["UserFullName"].ToString() : null,
                    TourId = doc.Contains("TourId") && !doc["TourId"].IsBsonNull ? doc["TourId"].ToString() : null,
                    TourTitle = doc.Contains("TourTitle") && !doc["TourTitle"].IsBsonNull ? doc["TourTitle"].ToString() : null,
                    QuestionContent = doc.Contains("QuestionContent") && !doc["QuestionContent"].IsBsonNull ? doc["QuestionContent"].ToString() : null,
                    AnswerContent = doc.Contains("AnswerContent") && !doc["AnswerContent"].IsBsonNull ? doc["AnswerContent"].ToString() : null,
                    CreatedAt = doc.Contains("CreatedAt") && !doc["CreatedAt"].IsBsonNull ? doc["CreatedAt"].ToUniversalTime() : DateTime.MinValue,
                    IsStatus = doc.Contains("IsStatus") && !doc["IsStatus"].IsBsonNull ? doc["IsStatus"].AsBoolean : false
                });
            }

            return resultQuestionDtos;
        }

        public async Task CreateQuestionAsync(CreateQuestionDto createQuestionDto)
        {
            var question = _mapper.Map<Question>(createQuestionDto);
            await _questionCollection.InsertOneAsync(question);
        }

        public async Task UpdateQuestionAsync(UpdateQuestionDto updateQuestionDto)
        {
            var question = _mapper.Map<Question>(updateQuestionDto);
            await _questionCollection.FindOneAndReplaceAsync(x => x.Id == updateQuestionDto.Id, question);
        }

        public async Task DeleteQuestionAsync(string id)
        {
            await _questionCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task<UpdateQuestionDto> GetByIdQuestionAsync(string id)
        {
            var value = await _questionCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<UpdateQuestionDto>(value);
        }
    }
}
