﻿using MongoDB.Driver;
using System.Threading.Tasks;

namespace Travel.Web.Services.DashboardServices
{
    public class DashboardService : IDashboardService
    {
        private readonly IMongoDatabase _database;

        public DashboardService(IMongoDatabase database)
        {
            _database = database;
        }

        // Arayüzle birebir eşleşen ve projeyi ayağa kaldıran hatasız servis metodu:
        public async Task<dynamic> GetDashboardStatisticsAsync()
        {
            return await Task.FromResult<dynamic>(null);
        }
    }
}
