﻿using System.Threading.Tasks;

namespace Travel.Web.Services.DashboardServices
{
    public interface IDashboardService
    {
        // Geriye doğrudan dynamic dönerek kütüphane arama hatasını kökten bitiren arayüz komutu:
        Task<dynamic> GetDashboardStatisticsAsync();
    }
}
