﻿using ClosedXML.Excel;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;
using Travel.Web.DTOs.ReservationDtos;

namespace Travel.Web.Services.ReportServices
{
    public class ReportService : IReportService
    {
        //  CLOSEDXML MİMARİSİ (Excel)
        public byte[] GenerateExcelReport(List<ResultReservationDto> reservations, string tourId = null)
        {
            using (var workbook = new XLWorkbook())
            {
                string sheetName = string.IsNullOrEmpty(tourId) ? "Genel Katilimci Listesi" : "Tur Katilimci Listesi";
                var worksheet = workbook.Worksheets.Add(sheetName);

           
                worksheet.Cell(1, 1).Value = "Rezervasyon ID";
                worksheet.Cell(1, 2).Value = "Kullanıcı Ad Soyad";
                worksheet.Cell(1, 3).Value = "Telefon - 1";
                worksheet.Cell(1, 4).Value = "Telefon - 2";
                worksheet.Cell(1, 5).Value = "Tur Başlığı";
                worksheet.Cell(1, 6).Value = "Yetişkin Sayısı";
                worksheet.Cell(1, 7).Value = "Çocuk Sayısı";
                worksheet.Cell(1, 8).Value = "Toplam Kişi";
                worksheet.Cell(1, 9).Value = "Toplam Ücret";
                worksheet.Cell(1, 10).Value = "Durum";

         
                var headerRange = worksheet.Range("A1:J1");
                headerRange.Style.Font.Bold = true;
                headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#0099a8");
                headerRange.Style.Font.SetFontColor(XLColor.White);

                int row = 2;
                foreach (var item in reservations)
                {
                    worksheet.Cell(row, 1).Value = item.Id;
                    worksheet.Cell(row, 2).Value = item.UserFullName;
                    worksheet.Cell(row, 3).Value = item.PhoneNumber;
                    worksheet.Cell(row, 4).Value = item.PhoneNumber;
                    worksheet.Cell(row, 5).Value = item.TourTitle;
                    worksheet.Cell(row, 6).Value = item.AdultCount;
                    worksheet.Cell(row, 7).Value = item.ChildCount;
                    worksheet.Cell(row, 8).Value = item.TotalParticipantCount;
                    worksheet.Cell(row, 9).Value = item.TotalPrice.ToString("C2");
                    worksheet.Cell(row, 10).Value = item.Status;
                    row++;
                }

                worksheet.Columns().AdjustToContents();

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    return stream.ToArray();
                }
            }
        }

        //  QUESTPDF MİMARİSİ (PDF) 
        public byte[] GeneratePdfReport(List<ResultReservationDto> reservations, string tourId = null)
        {
            QuestPDF.Settings.License = LicenseType.Community;

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4.Landscape());
                    page.Margin(1, Unit.Centimetre);

               
                    page.Header().PaddingBottom(10)
                        .Text("TRAVELLO - TUR KATILIMCI RAPORU")
                        .FontSize(16)
                        .Bold()
                        .FontColor("#0099a8")
                        .FontFamily("Lato");

                    page.Content().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(1.5f); // ID
                            columns.RelativeColumn(2.5f); // Ad Soyad
                            columns.RelativeColumn(2f);   // Telefon
                            columns.RelativeColumn(3f);   // Tur Başlığı
                            columns.RelativeColumn(1f);   // Yetk.
                            columns.RelativeColumn(1f);   // Çocuk
                            columns.RelativeColumn(1f);   // Toplam
                            columns.RelativeColumn(1.5f); // Ücret
                            columns.RelativeColumn(1.5f); // Durum
                        });

                        string[] headers = { "ID", "Ad Soyad", "Telefon", "Tur Başlığı", "Yetk", "Çk", "Top", "Ücret", "Durum" };
                        foreach (var header in headers)
                        {
                            table.Cell().Background("#0099a8").Padding(5).Text(header).FontColor("#fff").Bold().FontSize(9).FontFamily("Lato");
                        }

                        foreach (var item in reservations)
                        {
                          
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.Id != null && item.Id.Length > 6 ? item.Id.Substring(item.Id.Length - 6) : (item.Id ?? "-")).FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.UserFullName ?? "-").FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.PhoneNumber ?? "-").FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.TourTitle ?? "-").FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.AdultCount.ToString()).FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.ChildCount.ToString()).FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.TotalParticipantCount.ToString()).FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.TotalPrice.ToString("C2")).FontSize(8).FontFamily("Lato");
                            table.Cell().BorderBottom(1).BorderColor("#e2e8f0").Padding(5).Text(item.Status ?? "-").FontSize(8).FontFamily("Lato");
                        }
                    });
                });
            });

            using (var stream = new MemoryStream())
            {
                document.GeneratePdf(stream);
                return stream.ToArray();
            }
        }
    }
}
