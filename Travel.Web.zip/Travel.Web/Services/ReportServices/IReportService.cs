﻿using System.Collections.Generic;
using Travel.Web.DTOs.ReservationDtos;

namespace Travel.Web.Services.ReportServices
{
    public interface IReportService
    {
        byte[] GenerateExcelReport(List<ResultReservationDto> reservations, string tourId = null);
        byte[] GeneratePdfReport(List<ResultReservationDto> reservations, string tourId = null);
    }
}
