﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.CommentDtos;
using Travel.Web.Entities;
using Travel.Web.Settings;

namespace Travel.Web.Services.CommentServices
{
    public class CommentService : ICommentService
    {
        private readonly IMongoCollection<Comment> _commentCollection;
        private readonly IMapper _mapper;

        public CommentService(IMapper mapper, IDatabaseSettings databaseSettings)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            var database = client.GetDatabase(databaseSettings.DatabaseName);

            _commentCollection = database.GetCollection<Comment>(databaseSettings.CommentCollectionName);
            _mapper = mapper;
        }

        public async Task<List<ResultCommentDto>> GetAllCommentAsync()
        {
            var pipeline = new BsonDocument[]
            {
           
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Users" },
                    { "localField", "UserId" },
                    { "foreignField", "_id" },
                    { "as", "UserData" }
                }),
             
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$UserData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
            
                new BsonDocument("$lookup", new BsonDocument
                {
                    { "from", "Tours" },
                    { "localField", "TourId" },
                    { "foreignField", "_id" },
                    { "as", "TourData" }
                }),
            
                new BsonDocument("$unwind", new BsonDocument
                {
                    { "path", "$TourData" },
                    { "preserveNullAndEmptyArrays", true }
                }),
            
                new BsonDocument("$project", new BsonDocument
                {
                    { "_id", 1 },
                    { "UserId", "$UserId" },
                    { "UserFullName", "$UserData.NameSurname" },
                    { "TourId", "$TourId" },
                    { "TourTitle", "$TourData.Title" },
                    { "Content", "$Content" },
                    { "Rating", "$Rating" },
                    { "CreatedAt", "$CreatedAt" },
                    { "IsActive", "$IsActive" }
                })
            };

            
            var aggregateFluent = await _commentCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
            var resultCommentDtos = new List<ResultCommentDto>();

            foreach (var doc in aggregateFluent)
            {
                resultCommentDtos.Add(new ResultCommentDto
                {
                    Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                    UserId = doc.Contains("UserId") && !doc["UserId"].IsBsonNull ? doc["UserId"].ToString() : null,
                    UserFullName = doc.Contains("UserFullName") && !doc["UserFullName"].IsBsonNull ? doc["UserFullName"].ToString() : null,
                    TourId = doc.Contains("TourId") && !doc["TourId"].IsBsonNull ? doc["TourId"].ToString() : null,
                    TourTitle = doc.Contains("TourTitle") && !doc["TourTitle"].IsBsonNull ? doc["TourTitle"].ToString() : null,
                    Content = doc.Contains("Content") && !doc["Content"].IsBsonNull ? doc["Content"].ToString() : null,
                    Rating = doc.Contains("Rating") && !doc["Rating"].IsBsonNull ? doc["Rating"].AsInt32 : 0,
                    CreatedAt = doc.Contains("CreatedAt") && !doc["CreatedAt"].IsBsonNull ? doc["CreatedAt"].ToUniversalTime() : DateTime.MinValue,
                    IsActive = doc.Contains("IsActive") && !doc["IsActive"].IsBsonNull ? doc["IsActive"].AsBoolean : false
                });
            }

            return resultCommentDtos;
        }

        public async Task CreateCommentAsync(CreateCommentDto createCommentDto)
        {
            var comment = _mapper.Map<Comment>(createCommentDto);
            await _commentCollection.InsertOneAsync(comment);
        }

        public async Task UpdateCommentAsync(UpdateCommentDto updateCommentDto)
        {
            var comment = _mapper.Map<Comment>(updateCommentDto);
            await _commentCollection.FindOneAndReplaceAsync(x => x.Id == updateCommentDto.Id, comment);
        }

        public async Task DeleteCommentAsync(string id)
        {
            await _commentCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task<UpdateCommentDto> GetByIdCommentAsync(string id)
        {
            var value = await _commentCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<UpdateCommentDto>(value);
        }
    }
}
