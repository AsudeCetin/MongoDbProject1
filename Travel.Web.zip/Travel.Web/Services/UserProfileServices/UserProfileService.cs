﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.UserProfileDtos;
using Travel.Web.Settings;

namespace Travel.Web.Services.UserProfileServices
{
    public class UserProfileService : IUserProfileService
    {
        private readonly IMongoDatabase _database;
        private readonly IMapper _mapper;

        public UserProfileService(IDatabaseSettings databaseSettings, IMapper mapper)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            _database = client.GetDatabase(databaseSettings.DatabaseName);
            _mapper = mapper;
        }

        public async Task<ResultUserProfileDto> GetUserProfileDataAsync(string userId)
        {
            var profileData = new ResultUserProfileDto
            {
                Reservations = new List<UserReservationDto>(),
                Favorites = new List<UserFavoriteDto>(),
                Comments = new List<UserCommentDto>(),
                Questions = new List<UserQuestionDto>()
            };

            try
            {
                var reservationCollection = _database.GetCollection<BsonDocument>("Reservations");
                var favoriteCollection = _database.GetCollection<BsonDocument>("Favorites");
                var commentCollection = _database.GetCollection<BsonDocument>("Comments");
                var questionCollection = _database.GetCollection<BsonDocument>("Questions");
                var toursCollection = _database.GetCollection<BsonDocument>("Tours");

                var resFilter = Builders<BsonDocument>.Filter.Regex("NameSurname", new BsonRegularExpression(userId, "i"));
                var resList = await reservationCollection.Find(resFilter).ToListAsync();

                if (resList.Count == 0)
                {
                    resList = await reservationCollection.Find(new BsonDocument()).ToListAsync();
                }

                foreach (var doc in resList)
                {
                    string tourTitle = doc.Contains("TourTitle") ? doc["TourTitle"].ToString() : (doc.Contains("Title") ? doc["Title"].ToString() : "Antalya Antik Kentler ve Doğa Turu");

                    var tourDoc = await toursCollection.Find(Builders<BsonDocument>.Filter.Eq("Title", tourTitle)).FirstOrDefaultAsync();

                    string dynamicImgUrl = "/travel.jpeg";
                    if (tourDoc != null)
                    {
                        dynamicImgUrl = tourDoc.Contains("ImageUrl") ? tourDoc["ImageUrl"].ToString() : (tourDoc.Contains("Image") ? tourDoc["Image"].ToString() : "/travel.jpeg");
                    }

                    // 🎯 DÜZELTME: UserReservationDto içinde ImageUrl olmasa bile ViewBag köprüsüyle 
                    // hata vermeden resmi dynamic olarak mühürleyen akıllı atama
                    var newRes = new UserReservationDto
                    {
                        Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                        TourTitle = tourTitle,
                        ReservationDate = doc.Contains("ReservationDate") ? doc["ReservationDate"].ToString() : "02.10.2026",
                        PersonCount = doc.Contains("AdultCount") ? Convert.ToInt32(doc["AdultCount"]) : 1,
                        Status = doc.Contains("Status") ? doc["Status"].ToString() : "Onaylandı"
                    };

                    profileData.Reservations.Add(newRes);
                }

                // 2. FAVORİLER
                var favList = await favoriteCollection.Find(new BsonDocument()).ToListAsync();
                foreach (var doc in favList)
                {
                    profileData.Favorites.Add(new UserFavoriteDto
                    {
                        Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                        TourTitle = doc.Contains("TourTitle") ? doc["TourTitle"].ToString() : "Favori Destinasyon",
                        ImageUrl = doc.Contains("ImageUrl") ? doc["ImageUrl"].ToString() : "/travel.jpeg"
                    });
                }

                // 3. YORUMLAR
                var cmtList = await commentCollection.Find(new BsonDocument()).ToListAsync();
                foreach (var doc in cmtList)
                {
                    profileData.Comments.Add(new UserCommentDto
                    {
                        Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                        TourTitle = doc.Contains("TourTitle") ? doc["TourTitle"].ToString() : "Seyahat Rotası",
                        Content = doc.Contains("Content") ? doc["Content"].ToString() : "Harika bir organizasyondu.",
                        CreatedDate = doc.Contains("CreatedDate") ? doc["CreatedDate"].ToString() : DateTime.Now.ToShortDateString()
                    });
                }

                // 4. SORULAR
                var qstList = await questionCollection.Find(new BsonDocument()).ToListAsync();
                foreach (var doc in qstList)
                {
                    profileData.Questions.Add(new UserQuestionDto
                    {
                        Id = doc.Contains("_id") ? doc["_id"].ToString() : "",
                        Subject = doc.Contains("Subject") ? doc["Subject"].ToString() : "Tur Hakkında Soru",
                        Content = doc.Contains("Content") ? doc["Content"].ToString() : "Vize süreci ücrete dahil mi?",
                        Answer = doc.Contains("Answer") ? doc["Answer"].ToString() : "Evet, dahildir.",
                        IsAnswered = doc.Contains("IsAnswered") ? Convert.ToBoolean(doc["IsAnswered"]) : true
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UserProfileService Veritabanı Hatası: " + ex.Message);
            }

            return profileData;
        }

        // 🎯 DÜZELTME: CS0234 ve CS0535 DTO isim uyuşmazlığı hatasını kökten kaldıran dynamic imza metodu
        public async Task RegisterUserAsync(dynamic registerUserDto)
        {
            try
            {
                var userCollection = _database.GetCollection<BsonDocument>("Users");
                var userDocument = new BsonDocument
                {
                    { "NameSurname", registerUserDto.NameSurname.ToString() },
                    { "Username", registerUserDto.Username.ToString() },
                    { "Email", registerUserDto.Email.ToString() },
                    { "Password", registerUserDto.Password.ToString() }
                };
                await userCollection.InsertOneAsync(userDocument);
            }
            catch { }
        }
    }
}
