﻿using System.Threading.Tasks;
using Travel.Web.DTOs.UserProfileDtos;

namespace Travel.Web.Services.UserProfileServices
{
    public interface IUserProfileService
    {
        Task<ResultUserProfileDto> GetUserProfileDataAsync(string userId);
        Task RegisterUserAsync(dynamic registerUserDto); // dynamic kilit çözücü imza
    }
}
