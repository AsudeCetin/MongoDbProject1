﻿using Travel.Web.DTOs.UserDtos;

namespace Travel.Web.Services.UserServices
{
    public interface IUserService
    {
        Task<List<ResultUserDto>> GetAllAsync();
        Task<UpdateUserDto> GetByIdAsync(string id);
        Task CreateAsync(CreateUserDto createUserDto);
        Task UpdateAsync(UpdateUserDto updateUserDto);
        Task DeleteAsync(string id);
    }
}
