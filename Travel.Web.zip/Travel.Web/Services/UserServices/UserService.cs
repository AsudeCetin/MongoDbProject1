﻿using AutoMapper;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.UserDtos;
using Travel.Web.Entities;
using Travel.Web.Settings;

namespace Travel.Web.Services.UserServices
{
    public class UserService : IUserService
    {
        private readonly IMongoCollection<User> _userCollection;
        private readonly IMapper _mapper;

        public UserService(IDatabaseSettings databaseSettings, IMapper mapper)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            var database = client.GetDatabase(databaseSettings.DatabaseName);
            _userCollection = database.GetCollection<User>(databaseSettings.UserCollectionName);
            _mapper = mapper;
        }

        public async Task CreateAsync(CreateUserDto createUserDto)
        {
            var user = _mapper.Map<User>(createUserDto);
            await _userCollection.InsertOneAsync(user);
        }

        public async Task DeleteAsync(string id)
        {
            await _userCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task<List<ResultUserDto>> GetAllAsync()
        {
            var users = await _userCollection.AsQueryable().ToListAsync();
            return _mapper.Map<List<ResultUserDto>>(users);
        }

        public async Task<UpdateUserDto> GetByIdAsync(string id)
        {
            var user = await _userCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<UpdateUserDto>(user);
        }

        public async Task UpdateAsync(UpdateUserDto updateUserDto)
        {
            var user = _mapper.Map<User>(updateUserDto);
            await _userCollection.ReplaceOneAsync(x => x.Id == user.Id, user);
        }
    }
}

