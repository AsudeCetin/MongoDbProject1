﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Travel.Web.DTOs.ReservationDtos;

namespace Travel.Web.Services.ReservationServices
{
    public interface IReservationService
    {
        Task<List<ResultReservationDto>> GetAllReservationAsync();
        Task CreateReservationAsync(CreateReservationDto createReservationDto);
        Task UpdateReservationAsync(UpdateReservationDto updateReservationDto);
        Task DeleteReservationAsync(string id);
        Task<UpdateReservationDto> GetByIdReservationAsync(string id);
    }
}
