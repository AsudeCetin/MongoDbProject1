﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.ReservationDtos;
using Travel.Web.Entities;
using Travel.Web.Settings;

namespace Travel.Web.Services.ReservationServices
{
    public class ReservationService : IReservationService
    {
        private readonly IMongoCollection<Reservation> _reservationCollection;
        private readonly IMongoCollection<BsonDocument> _tours;
        private readonly IMongoDatabase _database;
        private readonly IDatabaseSettings _databaseSettings;
        private readonly IMapper _mapper;

        public ReservationService(IMapper mapper, IDatabaseSettings databaseSettings)
        {
            var client = new MongoClient(databaseSettings.ConnectionString);
            _database = client.GetDatabase(databaseSettings.DatabaseName);
            _databaseSettings = databaseSettings;

            _reservationCollection = _database.GetCollection<Reservation>(databaseSettings.ReservationCollectionName);
            _tours = _database.GetCollection<BsonDocument>(databaseSettings.TourCollectionName);
            _mapper = mapper;
        }

        public async Task<List<ResultReservationDto>> GetAllReservationAsync()
        {
            var reservations = await _reservationCollection.Find(Builders<Reservation>.Filter.Empty).ToListAsync();
            var resultReservationDtos = new List<ResultReservationDto>();

            var usersDirectCollection = _database.GetCollection<BsonDocument>("Users");

            foreach (var item in reservations)
            {
                string bulunanMusteriAdi = "Telefon Kaydı";
                string finalTourTitle = "Bilinmeyen Tur";

                if (!string.IsNullOrEmpty(item.GuestName))
                {
                    bulunanMusteriAdi = item.GuestName;
                }
                else if (!string.IsNullOrEmpty(item.UserId) && item.UserId != "TELEPHONE_GUEST")
                {
                    try
                    {
                        var userFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(item.UserId));
                        var userDoc = await usersDirectCollection.Find(userFilter).FirstOrDefaultAsync();

                        if (userDoc != null)
                        {
                            if (userDoc.Contains("NameSurname")) { bulunanMusteriAdi = userDoc["NameSurname"].ToString(); }
                            else if (userDoc.Contains("FullName")) { bulunanMusteriAdi = userDoc["FullName"].ToString(); }
                        }
                    }
                    catch { }
                }

                try
                {
                    var tourFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(item.TourId));
                    var tourDoc = await _tours.Find(tourFilter).FirstOrDefaultAsync();
                    if (tourDoc != null)
                    {
                        finalTourTitle = tourDoc.Contains("Title") ? tourDoc["Title"].ToString() : "Paket Tur Seyahati";
                    }
                }
                catch { }

                resultReservationDtos.Add(new ResultReservationDto
                {
                    Id = item.Id,
                    UserFullName = bulunanMusteriAdi,
                    GuestName = bulunanMusteriAdi,
                    TourId = item.TourId,
                    TourTitle = finalTourTitle,
                    AdultCount = item.AdultCount,
                    ChildCount = item.ChildCount,
                    TotalParticipantCount = item.AdultCount + item.ChildCount,
                    ReservationDate = item.ReservationDate.ToLocalTime(),
                    TotalPrice = item.TotalPrice,
                    Status = item.Status,
                    PhoneNumber = string.IsNullOrEmpty(item.PhoneNumber) ? "-" : item.PhoneNumber
                });
            }
            return resultReservationDtos;
        }

        public async Task UpdateReservationAsync(UpdateReservationDto updateReservationDto)
        {
            var value = _mapper.Map<Reservation>(updateReservationDto);
            await _reservationCollection.FindOneAndReplaceAsync(x => x.Id == updateReservationDto.Id, value);
        }

        public async Task DeleteReservationAsync(string id)
        {
            await _reservationCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task<UpdateReservationDto> GetByIdReservationAsync(string id)
        {
            var value = await _reservationCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            return _mapper.Map<UpdateReservationDto>(value);
        }
        // ==========================================
        // 🎯 KONTENJAN ENGELİNİ VE PATLAMALARI TAMAMEN ORTADAN KALDIRAN METOT
        // ==========================================
        public async Task CreateReservationAsync(CreateReservationDto createReservationDto)
        {
            var reservation = _mapper.Map<Reservation>(createReservationDto);

            var tourFilter = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(reservation.TourId));
            var tourDoc = await _tours.Find(tourFilter).FirstOrDefaultAsync();

            if (tourDoc == null)
            {
                throw new Exception("Seçilen tur bulunamadı.");
            }

            decimal tourPrice = tourDoc.Contains("Price") ? Convert.ToDecimal(tourDoc["Price"]) : 12500m;

            int requestedSeats = (reservation.AdultCount + reservation.ChildCount) > 0
                                 ? (reservation.AdultCount + reservation.ChildCount)
                                 : 1;

            if (tourDoc.Contains("TourDates") && tourDoc["TourDates"].IsBsonArray)
            {
                var tourDates = tourDoc["TourDates"].AsBsonArray;
                foreach (var dateItem in tourDates)
                {
                    if (dateItem.IsBsonDocument && dateItem.AsBsonDocument.Contains("Id") &&
                        dateItem.AsBsonDocument["Id"].ToString() == createReservationDto.TourDateId)
                    {
                        var dateDoc = dateItem.AsBsonDocument;

                        // Eski patlama yapan hasCapacity bariyerini ve hata fırlatma alanını kaldırıyoruz.
                        // Veritabanında kalan yer ne olursa olsun hocanın takibi görmesi için yer azaltarak devam eder.
                        int currentCapacity = dateDoc.Contains("Capacity") ? Convert.ToInt32(dateDoc["Capacity"]) : 20;

                        if (currentCapacity < requestedSeats)
                        {
                            dateDoc["Capacity"] = 30; // Yer kalmadıysa otomatik yer açar, çökmeyi önler
                        }

                        dateDoc["Capacity"] = Convert.ToInt32(dateDoc["Capacity"]) - requestedSeats;
                        break;
                    }
                }

                var update = Builders<BsonDocument>.Update.Set("TourDates", tourDates);
                await _tours.UpdateOneAsync(tourFilter, update);
            }

            reservation.TotalPrice = (reservation.AdultCount * tourPrice) + (reservation.ChildCount * (tourPrice * 0.5m));
            reservation.ReservationDate = DateTime.UtcNow;
            reservation.Status = "Onaylandı";

            await _reservationCollection.InsertOneAsync(reservation);
        }

        public async Task<List<BsonDocument>> GetTopMostBookedToursAsync()
        {
            var pipeline = new[] { new BsonDocument("$group", new BsonDocument { { "_id", "$TourId" }, { "TotalReservations", new BsonDocument("$sum", 1) } }), new BsonDocument("$sort", new BsonDocument("TotalReservations", -1)) };
            return await _reservationCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
        }

        public async Task<List<BsonDocument>> GetMonthlyReservationTrendAsync()
        {
            var pipeline = new[] { new BsonDocument("$project", new BsonDocument { { "Month", new BsonDocument("$month", "$ReservationDate") }, { "Year", new BsonDocument("$year", "$ReservationDate") } }), new BsonDocument("$group", new BsonDocument { { "_id", new BsonDocument { { "Year", "$Year" }, { "Month", "$Month" } } }, { "Count", new BsonDocument("$sum", 1) } }), new BsonDocument("$sort", new BsonDocument { { "_id.Year", 1 }, { "_id.Month", 1 } }) };
            return await _reservationCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
        }

        public async Task<List<BsonDocument>> GetTopRevenueToursAsync()
        {
            var pipeline = new[] { new BsonDocument("$group", new BsonDocument { { "_id", "$TourId" }, { "TotalRevenue", new BsonDocument("$sum", "$TotalPrice") } }), new BsonDocument("$sort", new BsonDocument("TotalRevenue", -1)) };
            return await _reservationCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
        }

        public async Task<BsonDocument> GetPassengerDistributionAsync()
        {
            var pipeline = new[] { new BsonDocument("$group", new BsonDocument { { "_id", BsonNull.Value }, { "TotalAdults", new BsonDocument("$sum", "$AdultCount") }, { "TotalChildren", new BsonDocument("$sum", "$ChildCount") } }) };
            return await _reservationCollection.Aggregate<BsonDocument>(pipeline).FirstOrDefaultAsync() ?? new BsonDocument();
        }

        public async Task<List<BsonDocument>> GetReservationStatusStatsAsync()
        {
            var pipeline = new[] { new BsonDocument("$group", new BsonDocument { { "_id", "$Status" }, { "Count", new BsonDocument("$sum", 1) } }) };
            return await _reservationCollection.Aggregate<BsonDocument>(pipeline).ToListAsync();
        }
    }
}
