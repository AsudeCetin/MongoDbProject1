﻿using AutoMapper;
using Travel.Web.DTOs.UserDtos;
using user = Travel.Web.Entities.User;

namespace Travel.Web.Mappings
{
    public class UserMappings : Profile
    {
        public UserMappings()
        {
            CreateMap<CreateUserDto, user>().ReverseMap();
            CreateMap<UpdateUserDto, user>().ReverseMap();

            CreateMap<user, ResultUserDto>().ReverseMap();
            CreateMap<ResultUserDto, UpdateUserDto>().ReverseMap();
        }
    }
}
