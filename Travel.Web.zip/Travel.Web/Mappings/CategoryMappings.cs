﻿using AutoMapper;
using Travel.Web.DTOs.CategoryDtos;
using Travel.Web.Entities;

namespace Travel.Web.Mappings
{
    public class CategoryMappings : Profile
    {
        public CategoryMappings()
        {
         
            CreateMap<Category, CreateCategoryDto>().ReverseMap();
            CreateMap<Category, UpdateCategoryDto>().ReverseMap();
            CreateMap<Category, ResultCategoryDto>().ReverseMap();
            CreateMap<ResultCategoryDto, UpdateCategoryDto>().ReverseMap();
        }
    }
}
