﻿using AutoMapper;
using Travel.Web.DTOs.DestinationDtos;
using destination = Travel.Web.Entities.Destination;

namespace Travel.Web.Mappings
{
    public class DestinationMappings : Profile
    {
        public DestinationMappings()
        {
            CreateMap<CreateDestinationDto, destination>().ReverseMap();
            CreateMap<UpdateDestinationDto, destination>().ReverseMap();

            CreateMap<destination, ResultDestinationDto>().ReverseMap();
            CreateMap<ResultDestinationDto, UpdateDestinationDto>().ReverseMap();
        }
    }
}
