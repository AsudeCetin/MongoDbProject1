﻿using AutoMapper;
using TravelioProject.DTOs.DashboardDtos;

namespace Travel.Web.Mappings
{
    public class DashboardMappings : Profile
    {
        public DashboardMappings()
        {
            CreateMap<CreateDashboardDto, ResultDashboardDto>().ReverseMap();
            CreateMap<UpdateDashboardDto, ResultDashboardDto>().ReverseMap();
            CreateMap<ResultDashboardDto, UpdateDashboardDto>().ReverseMap();
        }
    }
}
