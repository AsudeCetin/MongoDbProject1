﻿using AutoMapper;
using MongoDB.Bson;
using Travel.Web.DTOs.UserProfileDtos;

namespace Travel.Web.Mappings
{
    public class ProfileMappings : Profile
    {
        public ProfileMappings()
        {
            CreateMap<CreateUserProfileDto, BsonDocument>().ReverseMap();
            CreateMap<UpdateUserProfileDto, BsonDocument>().ReverseMap();

            // Bu kritik satırın başındaki yorum işaretlerini (//) kaldırıp aktif ettik:
            CreateMap<RegisterUserDto, BsonDocument>().ReverseMap();
        }
    }
}
