﻿using AutoMapper;
using Travel.Web.DTOs.TourDtos;
using tour = Travel.Web.Entities.Tour;

namespace Travel.Web.Mappings
{
    public class TourMappings : Profile
    {
        public TourMappings()
        {
            CreateMap<CreateTourDto, tour>().ReverseMap();
            CreateMap<UpdateTourDto, tour>().ReverseMap();

            CreateMap<tour, ResultTourDto>().ReverseMap();
            CreateMap<ResultTourDto, UpdateTourDto>().ReverseMap();
        }
    }
}
