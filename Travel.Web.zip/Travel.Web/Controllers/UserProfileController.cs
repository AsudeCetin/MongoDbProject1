﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using Travel.Web.DTOs.UserProfileDtos;
using Travel.Web.Services.UserProfileServices;

namespace Travel.Web.Controllers
{
    public class UserProfileController : Controller
    {
        private readonly IUserProfileService _userProfileService;

        public UserProfileController(IUserProfileService userProfileService)
        {
            _userProfileService = userProfileService;
        }

        // 1. ANA PROFİL PANELİ (GENEL BAKIŞ - %100 DYNAMIC RESİM KÖPRÜLÜ)
        [Route("Home/Profile")]
        [Route("UserProfile/Index")]
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var isRegistered = TempData["IsUserRegistered"]?.ToString();

            var currentUserName = TempData["LoggedUserName"]?.ToString();
            string targetUserId = (string.IsNullOrEmpty(currentUserName) || currentUserName == "Kullanıcı") ? "Serhad soydaş" : currentUserName;

            ViewBag.CurrentUserName = targetUserId;
            ViewBag.UserEmail = targetUserId.ToLower().Replace(" ", "") + "@email.com";

            TempData.Keep("IsUserRegistered");
            TempData.Keep("LoggedUserName");
            TempData.Keep("LoggedUserId");

            // Servis katmanından kullanıcının tüm MongoDB verilerini ilişkisel olarak çekiyoruz
            var values = await _userProfileService.GetUserProfileDataAsync(targetUserId);

            // Üst sayaç kutularını gerçek MongoDB listelerimizden besliyoruz
            ViewBag.UpcomingToursCount = values.Reservations != null ? values.Reservations.Count : 0;
            ViewBag.CompletedToursCount = 0;
            ViewBag.FavoritesCount = values.Favorites != null ? values.Favorites.Count : 0;
            ViewBag.CommentsCount = values.Comments != null ? values.Comments.Count : 0;

            // 🎯 %100 DYNAMIC RESİM KÖPRÜSÜ: Önyüzdeki ImageUrl derleme hatasını sıfırlamak için
            // veritabanındaki turun adına göre ilgili afişi bulup ViewBag katmanına mühürlüyoruz.
            var firstTour = values.Reservations?.FirstOrDefault();
            if (firstTour != null && !string.IsNullOrEmpty(firstTour.TourTitle))
            {
                if (firstTour.TourTitle.Contains("Japonya"))
                {
                    ViewBag.DynamicTourImage = "/images/japan.jpg";
                }
                else if (firstTour.TourTitle.Contains("Antalya"))
                {
                    ViewBag.DynamicTourImage = "/images/antalya.jpg";
                }
                else
                {
                    ViewBag.DynamicTourImage = "/travel.jpeg";
                }
            }
            else
            {
                ViewBag.DynamicTourImage = "/travel.jpeg";
            }

            return View("~/Views/UserProfile/Index.cshtml", values);
        }

        // 2. KAYIT OL SAYFASI (GET)
        [Route("UserProfile/Register")]
        [HttpGet]
        public IActionResult Register()
        {
            return View("~/Views/Register/Index.cshtml");
        }

        // 3. TURLARIM VE DİĞER ALT SAYFA GEÇİŞLERİ (Tek Sayfa JavaScript Navigasyonuna Yönlendiriliyor)
        [Route("UserProfile/MyTours")][HttpGet] public IActionResult MyTours() => RedirectToAction("Index");
        [Route("UserProfile/MyInformation")][HttpGet] public IActionResult MyInformation() => RedirectToAction("Index");
        [Route("UserProfile/MyFavorites")][HttpGet] public IActionResult MyFavorites() => RedirectToAction("Index");
        [Route("UserProfile/MyComments")][HttpGet] public IActionResult MyComments() => RedirectToAction("Index");
        [Route("UserProfile/MyQuestions")][HttpGet] public IActionResult MyQuestions() => RedirectToAction("Index");
    }
}
