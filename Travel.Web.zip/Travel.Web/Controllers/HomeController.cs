using Microsoft.AspNetCore.Mvc;
using Travel.Web.Services.BannerServices; 
using Travel.Web.Services.TourServices;

namespace Travel.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBannerService _bannerService;
        private readonly ITourService _tourService;

        public HomeController(IBannerService bannerService, ITourService tourService)
        {
            _bannerService = bannerService;
            _tourService = tourService;
        }

     
        public async Task<IActionResult> Index()
        {
          
            var banners = await _bannerService.GetAllAsync();
            ViewBag.Banners = banners;
            var tours = await _tourService.GetAllAsync();
            var popularTours = tours.Where(x => x.IsActive).Take(3).ToList();

            return View(popularTours);
        }
    }
}
