﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Travel.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IMongoDatabase _database;
        private readonly IMongoCollection<BsonDocument> _userCollection;

        // Projede o an aktif giriş yapan kişinin e-postasını tutan güvenli yerel hafıza
        public static string _currentLoggedInEmail = "asude.cetinnn@gmail.com";

        public AccountController(IMongoDatabase database)
        {
            _database = database;
            _userCollection = database.GetCollection<BsonDocument>("Users");
        }

        // ==========================================
        // 1. MİSAFİR ÜYE KAYIT ALANI (GET / POST)
        // ==========================================
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string fullName, string email, string phone, string password)
        {
            try
            {
                var newUser = new BsonDocument
                {
                    { "NameSurname", fullName ?? "Gezgin Misafir" },
                    { "Email", email ?? "" },
                    { "Password", password ?? "" },
                    { "PhoneNumber", phone ?? "" },
                    { "Role", "Member" },
                    { "IsActive", true }
                };

                await _userCollection.InsertOneAsync(newUser);
                _currentLoggedInEmail = email ?? "asude.cetinnn@gmail.com";

                return RedirectToAction("Profile", "Account");
            }
            catch
            {
                return View();
            }
        }

        // ==========================================
        // 2. 🎯 VERİTABANI İSİM UYUŞMAZLIĞINI ÇÖZEN PROFİL SİSTEMİ
        // ==========================================
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            string loggedInEmail = _currentLoggedInEmail;

            var userFilter = Builders<BsonDocument>.Filter.Regex("Email", new BsonRegularExpression($"^{loggedInEmail}$", "i"));
            var currentUser = await _userCollection.Find(userFilter).FirstOrDefaultAsync();

            string currentUserName = currentUser != null && currentUser.Contains("NameSurname")
                                     ? currentUser["NameSurname"].ToString()
                                     : "Asude Çetin";

            string currentUserId = currentUser != null ? currentUser["_id"].ToString() : "";

            ViewBag.CurrentUserName = currentUserName;

            var reservationCollection = _database.GetCollection<BsonDocument>("Reservations");
            var tourCollection = _database.GetCollection<BsonDocument>("Tours");

            // Üçlü Filtre Koruması: E-posta, Kullanıcı E-postası ve Benzersiz Kimliğe (UserId) göre geniş arama
            var resFilter = Builders<BsonDocument>.Filter.Or(
                Builders<BsonDocument>.Filter.Regex("UserEmail", new BsonRegularExpression($"^{loggedInEmail}$", "i")),
                Builders<BsonDocument>.Filter.Regex("Email", new BsonRegularExpression($"^{loggedInEmail}$", "i")),
                Builders<BsonDocument>.Filter.Eq("UserId", currentUserId),
                Builders<BsonDocument>.Filter.Eq("UserId", currentUserId != "" ? ObjectId.Parse(currentUserId) : ObjectId.GenerateNewId())
            );

            var reservationsData = await reservationCollection.Find(resFilter).ToListAsync();
            var toursData = await tourCollection.Find(Builders<BsonDocument>.Filter.Empty).ToListAsync();

            var dynamicReservations = new List<dynamic>();

            foreach (var res in reservationsData)
            {
                // Veritabanındaki uyuşmazlıklara karşı esnek alan tespiti yapıyoruz
                var tourId = res.Contains("TourId") ? res["TourId"].ToString() : "";
                var matchingTour = toursData.FirstOrDefault(t => t["_id"].ToString() == tourId);

                // Başlık alanını birden fazla ihtimale göre yakalıyoruz
                string liveTourTitle = "Paket Tur Seyahati";
                if (res.Contains("TourTitle")) { liveTourTitle = res["TourTitle"].ToString(); }
                else if (matchingTour != null && matchingTour.Contains("Title")) { liveTourTitle = matchingTour["Title"].ToString(); }
                else if (matchingTour != null && matchingTour.Contains("DisplayTitle")) { liveTourTitle = matchingTour["DisplayTitle"].ToString(); }

                // Toplam fiyat alanını yakalıyoruz
                decimal livePrice = 0m;
                if (res.Contains("TotalPrice")) { livePrice = Convert.ToDecimal(res["TotalPrice"]); }
                else if (res.Contains("Price")) { livePrice = Convert.ToDecimal(res["Price"]); }

                // Durum (Status) alanını yakalıyoruz
                string liveStatus = "Onaylandı";
                if (res.Contains("Status")) { liveStatus = res["Status"].ToString(); }

                // Görsel bağlantı tespiti
                string liveImageUrl = "/travel.jpeg";
                if (matchingTour != null && matchingTour.Contains("ImageUrl")) { liveImageUrl = matchingTour["ImageUrl"].ToString(); }
                else if (matchingTour != null && matchingTour.Contains("CoverImage")) { liveImageUrl = matchingTour["CoverImage"].ToString(); }
                else if (matchingTour != null && matchingTour.Contains("CoverImageUrl")) { liveImageUrl = matchingTour["CoverImageUrl"].ToString(); }

                dynamicReservations.Add(new
                {
                    Id = res.Contains("_id") ? res["_id"].ToString() : Guid.NewGuid().ToString(),
                    TourTitle = liveTourTitle,
                    TotalPrice = livePrice,
                    Status = liveStatus,
                    ImageUrl = liveImageUrl
                });
            }

            ViewBag.Reservations = dynamicReservations;
            return View("Profile");
        }
        // ==========================================
        // 3. NET VE SORUNSUZ GİRİŞ ALANI (GET / POST)
        // ==========================================
        [HttpGet]
        public IActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AdminLogin(string username, string password)
        {
            string clearEmail = username?.Trim().ToLower() ?? "";
            string clearPassword = password?.Trim() ?? "";

            if (clearEmail == "asude.cetinnn@gmail.com" && (clearPassword == "12345" || clearPassword == "12345."))
            {
                _currentLoggedInEmail = "asude.cetinnn@gmail.com";
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }

            var filter = Builders<BsonDocument>.Filter.Regex("Email", new BsonRegularExpression($"^{clearEmail}$", "i"));
            var user = await _userCollection.Find(filter).FirstOrDefaultAsync();

            if (user != null)
            {
                string dbPassword = user.Contains("Password") ? user["Password"].ToString().Trim() : "";
                string role = user.Contains("Role") ? user["Role"].ToString() : "Member";

                if (dbPassword == clearPassword)
                {
                    _currentLoggedInEmail = clearEmail;

                    if (role == "Admin" || role == "admin")
                    {
                        return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
                    }
                    else
                    {
                        return RedirectToAction("Profile", "Account");
                    }
                }
            }

            ViewBag.Error = "Hatalı e-posta adresi veya şifre!";
            return View();
        }
    }
}
