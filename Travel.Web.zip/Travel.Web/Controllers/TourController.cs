﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Travel.Web.Services.CategoryServices;
using Travel.Web.Services.CommentServices;
using Travel.Web.Services.DestinationServices;
using Travel.Web.Services.ReservationServices;
using Travel.Web.Services.TourServices;



namespace Travel.Web.Controllers
{
    public class TourController : Controller
    {
        private readonly ITourService _tourService;
        private readonly ICategoryService _categoryService;
        private readonly IDestinationService _destinationService;
        private readonly IReservationService _reservationService;
        private readonly ICommentService _commentService;
        public TourController(ITourService tourService,
                              ICategoryService categoryService,
                              IDestinationService destinationService,
                              IReservationService reservationService,
                              ICommentService commentService) 
        {
            _tourService = tourService;
            _categoryService = categoryService;
            _destinationService = destinationService;
            _reservationService = reservationService;
            _commentService = commentService; 
        }


        public async Task<IActionResult> Index(string categoryId, string destinationId, decimal minPrice, decimal maxPrice, DateTime? startDate)
        {
            ViewBag.Categories = await _categoryService.GetAllAsync();
            ViewBag.Destinations = await _destinationService.GetAllAsync();

            ViewBag.SelectedCategory = categoryId;
            ViewBag.SelectedDestination = destinationId;
            ViewBag.MinPrice = minPrice;
            ViewBag.MaxPrice = maxPrice;
            ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");

            var tours = await _tourService.GetAllAsync();
            var activeTours = tours != null ? tours.Where(x => x != null).ToList() : new List<Travel.Web.DTOs.TourDtos.ResultTourDto>();

            if (!string.IsNullOrEmpty(categoryId)) activeTours = activeTours.FindAll(x => x.CategoryId == categoryId);
            if (!string.IsNullOrEmpty(destinationId)) activeTours = activeTours.FindAll(x => x.DestinationId == destinationId);
            if (minPrice > 0) activeTours = activeTours.FindAll(x => x.Price >= minPrice);
            if (maxPrice > 0) activeTours = activeTours.FindAll(x => x.Price <= maxPrice);

            return View(activeTours);
        }

        public async Task<IActionResult> Detail(string id)
        {
            if (string.IsNullOrEmpty(id)) return RedirectToAction("Index");
            var tourDto = await _tourService.GetByIdAsync(id);
            if (tourDto == null) return NotFound();
            return View(tourDto);
        }
        
        [HttpPost]
        public async Task<IActionResult> BookTour(string tourId, string tourTitle, string price)
        {
            try
            {
                string activeUser = Travel.Web.Controllers.AccountController._currentLoggedInEmail;

            
                string rawPrice = price?.Replace(".", "")?.Replace(",", "")?.Trim() ?? "12500";
                decimal parsedPrice = 12500m;
                decimal.TryParse(rawPrice, out parsedPrice);

          
                if (string.IsNullOrEmpty(activeUser) || activeUser == "asude.cetinnn@gmail.com")
                {
                    return RedirectToAction("Register", "Account", new
                    {
                        pendingTourId = tourId,
                        pendingTourTitle = tourTitle,
                        pendingPrice = parsedPrice
                    });
                }

                var databaseProperty = _tourService.GetType().GetField("_database", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                var database = databaseProperty?.GetValue(_tourService) as IMongoDatabase;

                if (database != null)
                {
                    var reservationCollection = database.GetCollection<BsonDocument>("Reservations");
                    var tourCollection = database.GetCollection<BsonDocument>("Tours");

                    var newReservation = new BsonDocument
                    {
                        { "TourId", tourId ?? "" },
                        { "TourTitle", tourTitle ?? "Paket Tur Seyahati" },
                        { "UserEmail", activeUser.Trim().ToLower() },
                        { "TotalPrice", Convert.ToDouble(parsedPrice) },
                        { "Status", "Onaylandı" },
                        { "ReservationDate", DateTime.UtcNow }
                    };
                    await reservationCollection.InsertOneAsync(newReservation);

                    if (!string.IsNullOrEmpty(tourId) && tourId.Length == 24)
                    {
                        var tourFilter = new BsonDocument { { "_id", ObjectId.Parse(tourId) } };
                        var tourUpdate = new BsonDocument { { "$inc", new BsonDocument { { "Capacity", -1 }, { "Slots", -1 } } } };
                        await tourCollection.UpdateOneAsync(tourFilter, tourUpdate);
                    }
                }

                return RedirectToAction("Profile", "Account");
            }
            catch
            {
                return RedirectToAction("Profile", "Account");
            }
        }

        public async Task<IActionResult> Destinations()
        {
            var destinations = await _destinationService.GetAllAsync();
            return View("Destinations", destinations != null ? destinations.ToList() : new List<Travel.Web.DTOs.DestinationDtos.ResultDestinationDto>());
        }

        public async Task<IActionResult> Comments()
        {
           
            var comments = await _commentService.GetAllCommentAsync();

         
            if (comments != null)
            {
                comments = comments.Where(x => x.IsActive == true).ToList();
            }

            return View(comments);
        }

    }
}
