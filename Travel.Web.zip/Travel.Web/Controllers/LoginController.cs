﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Travel.Web.Controllers
{
    public class LoginController : Controller
    {
       
        [Route("Login/SignIn")]
        [Route("Login/Index")]
        [HttpGet]
        public IActionResult SignIn()
        {
            return View("~/Views/Login/Index.cshtml");
        }

     
        [Route("Login/SignIn")]
        [HttpPost]
        public IActionResult SignIn(string username, string password)
        {
           
            if (string.IsNullOrEmpty(username))
            {
                ModelState.AddModelError("", "Kullanıcı adı alanı boş bırakılamaz.");
                return View("~/Views/Login/Index.cshtml");
            }

          
            TempData["IsUserRegistered"] = "True";
            TempData["LoggedUserName"] = "Serhad Soydaş";
            TempData["LoggedUserId"] = username.Trim();

         
            return RedirectToAction("Index", "UserProfile");
        }

        [Route("Login/LogOut")]
        public IActionResult LogOut()
        {
          
            TempData.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
