﻿namespace Travel.Web.DTOs.UserProfileDtos
{
    public class RegisterUserDto
    {
        public string NameSurname { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
    }
}
