﻿using System.Collections.Generic;

namespace Travel.Web.DTOs.UserProfileDtos
{
    public class ResultUserProfileDto
    {
        public List<UserReservationDto> Reservations { get; set; } = new();
        public List<UserFavoriteDto> Favorites { get; set; } = new();
        public List<UserCommentDto> Comments { get; set; } = new();
        public List<UserQuestionDto> Questions { get; set; } = new();
    }

    public class UserReservationDto
    {
        public string Id { get; set; }
        public string TourTitle { get; set; }
        public string ReservationDate { get; set; }
        public int PersonCount { get; set; }
        public string Status { get; set; }
    }

    public class UserFavoriteDto
    {
        public string Id { get; set; }
        public string TourId { get; set; }
        public string TourTitle { get; set; }
        public string ImageUrl { get; set; }
    }

    public class UserCommentDto
    {
        public string Id { get; set; }
        public string TourTitle { get; set; }
        public string Content { get; set; }
        public string CreatedDate { get; set; }
    }

    public class UserQuestionDto
    {
        public string Id { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string Answer { get; set; }
        public bool IsAnswered { get; set; }
    }
}
