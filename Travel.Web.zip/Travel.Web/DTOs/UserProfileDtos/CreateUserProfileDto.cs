﻿namespace Travel.Web.DTOs.UserProfileDtos
{
    public class CreateUserProfileDto
    {
        public string NameSurname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
    }
}
