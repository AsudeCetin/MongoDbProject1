﻿using System;

namespace Travel.Web.DTOs.FavoriteDtos
{
    public class UpdateFavoriteDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? TourId { get; set; }
        public string? GuestName { get; set; }
    }
}
