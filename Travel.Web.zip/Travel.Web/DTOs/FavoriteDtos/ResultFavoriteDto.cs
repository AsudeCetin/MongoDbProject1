﻿using System;

namespace Travel.Web.DTOs.FavoriteDtos
{
    public class ResultFavoriteDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? UserFullName { get; set; } 
        public string? TourId { get; set; }
        public string? TourTitle { get; set; }   
        public DateTime CreatedAt { get; set; }
        public string? GuestName { get; set; }
    }
}
