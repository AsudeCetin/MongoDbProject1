﻿using System;

namespace Travel.Web.DTOs.QuestionDtos
{
    public class CreateQuestionDto
    {
        public string? UserId { get; set; }
        public string? TourId { get; set; }
        public string? QuestionContent { get; set; }
        public string? AnswerContent { get; set; }
        public bool IsStatus { get; set; } = false;
    }
}
