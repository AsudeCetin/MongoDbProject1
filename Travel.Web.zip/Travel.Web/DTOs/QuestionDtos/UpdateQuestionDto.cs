﻿using System;

namespace Travel.Web.DTOs.QuestionDtos
{
    public class UpdateQuestionDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? TourId { get; set; }
        public string? QuestionContent { get; set; }
        public string? AnswerContent { get; set; }
        public bool IsStatus { get; set; }
    }
}
