﻿using System;

namespace Travel.Web.DTOs.CommentDtos
{
    public class UpdateCommentDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? TourId { get; set; }
        public string? Content { get; set; }
        public int Rating { get; set; }
        public bool IsActive { get; set; }
    }
}
