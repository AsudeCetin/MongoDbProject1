﻿using System;

namespace Travel.Web.DTOs.CommentDtos
{
    public class ResultCommentDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? UserFullName { get; set; }
        public string? TourId { get; set; }
        public string? TourTitle { get; set; } 
        public string? Content { get; set; }
        public int Rating { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsActive { get; set; }
    }
}
