﻿using System;
using System.Collections.Generic;
using Travel.Web.Entities;

namespace Travel.Web.DTOs.TourDtos
{
    public class UpdateTourDto
    {
        public string? Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Capacity { get; set; }
        public bool IsActive { get; set; }
        public string? DestinationId { get; set; }
        public string? CategoryId { get; set; }
        public string? ImageUrl { get; set; }


        public List<TourDate> TourDates { get; set; } = new();
        public List<DailyProgram> DailyPrograms { get; set; } = new();
        public List<string> Gallery { get; set; } = new();
        public List<string> Features { get; set; } = new();
    }
}
