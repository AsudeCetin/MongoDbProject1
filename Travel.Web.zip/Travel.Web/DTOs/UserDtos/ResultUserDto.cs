﻿namespace Travel.Web.DTOs.UserDtos
{
    public class ResultUserDto
    {
        public string? Id { get; set; }
        public string? NameSurname { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Role { get; set; }
        public bool IsActive { get; set; }
    }
}
