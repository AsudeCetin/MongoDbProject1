﻿namespace TravelioProject.DTOs.DashboardDtos
{
    public class ResultDashboardDto
    {
        public long TotalTourCount { get; set; }
        public long ActiveTourCount { get; set; }
        public long TotalReservationCount { get; set; }
        public long TotalUserCount { get; set; }
        public long PendingQuestionCount { get; set; }
        public List<PopularTourDto> PopularTours { get; set; } = new List<PopularTourDto>();
        public List<RecentReservationDto> RecentReservations { get; set; } = new List<RecentReservationDto>();
        public List<DashboardCommentDto> RecentComments { get; set; } = new List<DashboardCommentDto>();
        public List<DashboardQuestionDto> RecentQuestions { get; set; } = new List<DashboardQuestionDto>();
    }

    public class PopularTourDto
    {
        public string TourName { get; set; }
        public int ReservationCount { get; set; }
        public decimal Price { get; set; }
        public string CategoryName { get; set; }
        public string ImageUrl { get; set; } 
    }

    public class RecentReservationDto
    {
        public string ReservationId { get; set; }
        public string GuestName { get; set; }
        public string TourName { get; set; }
        public DateTime TourDate { get; set; }
        public int TotalPerson { get; set; }
        public decimal TotalPrice { get; set; }
        public string Status { get; set; }
    }

    public class DashboardCommentDto
    {
        public string CommentId { get; set; }
        public string NameSurname { get; set; }
        public string TourName { get; set; }
        public string Content { get; set; }
    }

    public class DashboardQuestionDto
    {
        public string QuestionId { get; set; }
        public string TourName { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string CreatedDate { get; set; }
    }
}
