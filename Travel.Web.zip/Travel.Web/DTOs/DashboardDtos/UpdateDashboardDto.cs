﻿namespace TravelioProject.DTOs.DashboardDtos
{
    public class UpdateDashboardDto
    {
        public string Id { get; set; } = null!;
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
    }
}
