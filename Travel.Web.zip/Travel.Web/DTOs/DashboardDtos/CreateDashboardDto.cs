﻿namespace TravelioProject.DTOs.DashboardDtos
{
    public class CreateDashboardDto
    {
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
    }
}
