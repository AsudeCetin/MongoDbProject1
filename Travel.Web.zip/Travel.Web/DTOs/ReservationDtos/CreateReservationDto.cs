﻿using System;

namespace Travel.Web.DTOs.ReservationDtos
{
    public class CreateReservationDto
    {
        public string? UserId { get; set; }
        public string? TourId { get; set; }

     
        public string? TourDateId { get; set; }

        public int AdultCount { get; set; }
        public int ChildCount { get; set; }
        public DateTime ReservationDate { get; set; } = DateTime.Now;
        public decimal TotalPrice { get; set; }
        public string? Status { get; set; } = "Bekliyor";
        public string? GuestName { get; set; }
        public string? PhoneNumber { get; set; }
    }
}
