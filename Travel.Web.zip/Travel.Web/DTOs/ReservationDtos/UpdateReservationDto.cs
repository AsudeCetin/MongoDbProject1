﻿using System;

namespace Travel.Web.DTOs.ReservationDtos
{
    public class UpdateReservationDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? TourId { get; set; }
        public int AdultCount { get; set; }
        public int ChildCount { get; set; }
        public DateTime ReservationDate { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Status { get; set; }
        public string? PhoneNumber { get; set; }
        public string? GuestName { get; set; } 
    }
}
