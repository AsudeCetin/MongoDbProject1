﻿using System;

namespace Travel.Web.DTOs.ReservationDtos
{
    public class ResultReservationDto
    {
        public string? Id { get; set; }
        public string? UserId { get; set; }
        public string? UserFullName { get; set; }
        public string? TourId { get; set; }
        public string? TourTitle { get; set; }
        public int AdultCount { get; set; }
        public int ChildCount { get; set; }
        public int TotalParticipantCount { get; set; }
        public DateTime ReservationDate { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Status { get; set; }
        public string? PhoneNumber { get; set; }
        public string? GuestName { get; set; }
       


    }
}
