﻿namespace Travel.Web.DTOs.CategoryDtos
{
    public class CreateCategoryDto
    {
        public string? CategoryName { get; set; }
        public string? Description { get; set; }
        public string? Icon { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
