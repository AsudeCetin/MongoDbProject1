﻿namespace Travel.Web.DTOs.DestinationDtos
{
    public class ResultDestinationDto
    {
        public string? Id { get; set; }
        public string? City { get; set; }
        public string? Country { get; set; }
        public string? ImageUrl { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public string? Title { get; set; }

    }
}
